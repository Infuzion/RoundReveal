package com.avx.roundreveal;
import android.animation.Animator;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;

public class RevealAnimation
{
    private Animator mAnimator;
    private View mView;
    private RevealOrigin mOrigin=RevealOrigin.BottomRight;
    private int mDuration=500;
    private Interpolator mInterpolator=new DecelerateInterpolator();
    private AnimationListener mListener;
    private AnimationOrigin mCustomOrigin;
    private int mStartDelay=0;

    public RevealAnimation()
    {

    }

    public int getStartDelay()
    {
        return mStartDelay;
    }

    public void setStartDelay(int startDelay)
    {
        mStartDelay=startDelay;
    }

    public View getView()
    {
        return mView;
    }

    public void setView(View view)
    {
        mView=view;
    }

    public RevealOrigin getOrigin()
    {
        return mOrigin;
    }

    public void setOrigin(RevealOrigin origin)
    {
        mOrigin=origin;
    }

    public AnimationOrigin getCustomOrigin()
    {
        return mCustomOrigin;
    }

    public void setCustomOrigin(AnimationOrigin origin)
    {
        mCustomOrigin=origin;
    }

    public int getDuration()
    {
        return mDuration;
    }

    public void setDuration(int duration)
    {
        mDuration=duration;
    }

    public Interpolator getInterpolator()
    {
        return mInterpolator;
    }

    public void setInterpolator(Interpolator interpolator)
    {
        mInterpolator=interpolator;
    }

    public void setAnimationListener(AnimationListener listener)
    {
        mListener=listener;
    }

    public Animator getAnimator()
    {
        return mAnimator;
    }

    public void playAnimation()
    {
        switch(getOrigin())
        {
            case Center:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight()/2, getView().getWidth()/2, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case TopLeft:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), 0, 0, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case TopRight:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), 0, getView().getWidth()/2, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case TopCenter:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), 0, getView().getWidth()/2, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case BottomLeft:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight(), 0, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case CenterLeft:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight()/2, 0, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case BottomRight:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight(), getView().getWidth(), 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case CenterRight:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight()/2, getView().getWidth(), 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case BottomCenter:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight(), getView().getWidth(), 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case CustomOrigin:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getCustomOrigin().getCoordinateX(), getCustomOrigin().getCoordinateY(), 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()));
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;
        }
    }

    public void reverseAnimation()
    {
        switch(getOrigin())
        {
            case Center:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight()/2, getView().getWidth()/2, (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case TopLeft:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), 0, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case TopRight:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), 0, getView().getWidth()/2, (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case TopCenter:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), 0, getView().getWidth()/2, (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case BottomLeft:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight(), 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case CenterLeft:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight()/2, 0, (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case BottomRight:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight(), getView().getWidth(), (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case CenterRight:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight()/2, getView().getWidth(), (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case BottomCenter:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getView().getHeight(), getView().getWidth(), (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;

            case CustomOrigin:
                mAnimator=ViewAnimationUtils.createCircularReveal(getView(), getCustomOrigin().getCoordinateX(), getCustomOrigin().getCoordinateY(), (int)Math.hypot(getView().getWidth(), getView().getHeight()), 0);
                mAnimator.setDuration(getDuration());
                mAnimator.setInterpolator(getInterpolator());
                mAnimator.setStartDelay(getStartDelay());
                mAnimator.start();
                break;
        }
    }
}
