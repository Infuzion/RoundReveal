package com.avx.roundreveal;
/**
 * From where the circle will originate.
 */
public enum RevealOrigin
{
    TopLeft, TopCenter, TopRight, BottomLeft, BottomCenter, BottomRight, CenterLeft, Center, CenterRight, CustomOrigin
}
