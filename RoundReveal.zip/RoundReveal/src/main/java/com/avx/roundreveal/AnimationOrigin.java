package com.avx.roundreveal;
public class AnimationOrigin
{
    private int mCoordinateX;
    private int mCoordinateY;

    public AnimationOrigin(int coordinateX, int coordinateY)
    {
        mCoordinateX=coordinateX;
        mCoordinateY=coordinateY;
    }

    public AnimationOrigin()
    {
    }

    public int getCoordinateX()
    {
        return mCoordinateX;
    }

    public void setCoordinateX(int coordinateX)
    {
        mCoordinateX=coordinateX;
    }

    public int getCoordinateY()
    {
        return mCoordinateY;
    }

    public void setCoordinateY(int coordinateY)
    {
        mCoordinateY=coordinateY;
    }
}
