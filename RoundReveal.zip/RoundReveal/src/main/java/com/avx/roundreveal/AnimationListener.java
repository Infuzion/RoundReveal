package com.avx.roundreveal;
public interface AnimationListener
{
    void onAnimationBegin();

    void onAnimationEnd();
}
